SB_GAMERZ!! WEBSITE
====================

Your uploaded SB_GAMERZ!! banner is used as the full-screen hero background.

YouTube channel:
https://www.youtube.com/@SB_Gamerzz-24

Files:
- index.html
- style.css
- script.js
- logo-banner.png

Preview:
Open index.html in Chrome.

Free hosting:
Upload these files to a GitHub repository and enable GitHub Pages.
