const nav = document.querySelector('.navbar');
const menu = document.querySelector('.menu-btn');
menu.addEventListener('click', () => nav.classList.toggle('open'));
document.querySelectorAll('nav a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
